import React from 'react';
import {NavLink} from 'react-router-dom'

class Personal extends React.Component {

}
export default Personal;